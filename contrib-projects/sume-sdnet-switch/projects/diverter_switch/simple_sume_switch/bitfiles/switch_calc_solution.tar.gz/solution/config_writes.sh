#!/bin/bash

${SUME_SDNET}/sw/sume/rwaxi -a 0x440200f0 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x440200f0 -w 0x00000000
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020050 -w 0x00000000
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020080 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020084 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020040 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020050 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020080 -w 0x00000010
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020084 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020040 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020050 -w 0x00000002
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020080 -w 0x00000100
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020084 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020040 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020050 -w 0x00000003
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020080 -w 0x00001000
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020084 -w 0x00000001
${SUME_SDNET}/sw/sume/rwaxi -a 0x44020040 -w 0x00000001
